namespace MomentaryMomentos.Models;

public class SupabaseSettings
{
    public string Url { get; set; } = string.Empty;
    public string AnonKey { get; set; } = string.Empty;
    public string StorageBucket { get; set; } = "videos";
}
