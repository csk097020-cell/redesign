using Microsoft.Extensions.Configuration;

namespace MomentaryMomentos.Services;

/// <summary>
/// Central place for environment configuration.
/// Loads from user secrets in development, appsettings.json and environment variables in production.
/// </summary>
public sealed class AppSettings
{
    // Supabase Configuration
    public string SupabaseUrl { get; init; } = string.Empty;
    public string SupabaseAnonKey { get; init; } = string.Empty;
    public string StorageBucketUserVideos { get; init; } = "user-videos";
    public string StorageBucketUserThumbnails { get; init; } = "user-thumbnails";

    // Stripe Configuration
    public string? StripePublishableKey { get; init; }

    // Sentry Configuration
    public string? SentryDsn { get; init; }

    public static AppSettings Load(IConfiguration config)
    {
        return new AppSettings
        {
            // Supabase
            SupabaseUrl = config["Supabase:Url"] ?? throw new InvalidOperationException("Supabase:Url not configured"),
            SupabaseAnonKey = config["Supabase:AnonKey"] ?? throw new InvalidOperationException("Supabase:AnonKey not configured"),
            StorageBucketUserVideos = config["Supabase:StorageBucket"] ?? "user-videos",
            StorageBucketUserThumbnails = config["Supabase:ThumbnailBucket"] ?? "user-thumbnails",

            // Stripe
            StripePublishableKey = config["Stripe:PublishableKey"],

            // Sentry
            SentryDsn = config["Sentry:Dsn"]
        };
    }
}
